A Panada module for working with multiple file uploads, based on the BlueImp jQuery File Upload

Installation
------------

* Download this module from https://github.com/panada/JUpload/archive/master.zip
* Extract it and move to your app/Modules/ folder ini your Panada application
* Open your browser http://yoursite.com/index.php/JUpload/basic
